VNC
===

Running X11 in a Cloud9 workspace.

![Screen Shot](screenshot.png)

Installation
------------

    ./install.sh

Running
-------

    ./run.sh
    
or use the `X11` runner.
